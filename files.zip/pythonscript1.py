import pythonscript2
import time

def loop():

	while True: 
		pythonscript2.helloWorld()
		time.sleep(5)

loop()
